<div class="container">
	<h3>Hubungi Kami <i class="fas fa-headset"></i></h3>
	<span class="garis mb-2"></span>

	<div class="row">
		<div class="col-12">
			<h3><i class="fab fa-whatsapp"></i> +62 xxxx-xxxx</h3>
			<h3><i class="fab fa-facebook"></i> Rental Fiesto</h3>
			<h3><i class="fab fa-instagram"></i> @Rental_Fiesto</h3>
			<h3><i class="fas fa-envelope-square"></i> rental_fiesto@gmail.com</h3>
			
		</div>
	</div>
</div>