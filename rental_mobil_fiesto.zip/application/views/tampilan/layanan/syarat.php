<div class="container">
	<h3>Syarat & Ketentuan <i class="fas fa-info-circle"></i></h3>
	<span class="garis mb-2"></span>

	<div class="row">
		<div class="col-12">
			<h3>Berisi tentang syarat & ketentuan dirental mobil fiesto</h3>
		</div>
	</div>
</div>