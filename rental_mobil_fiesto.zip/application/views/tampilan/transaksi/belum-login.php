<div class="row">
	<div class="col-12">
    <h5 class="text-center">Masuk sebagai member untuk melanjutkan</h5>
    <a class="btn tombol-masuk btn-block" href="<?php echo base_url('masuk'); ?>">Masuk</a>
    <h5 class="text-center">Atau</h5>
    <h5 class="text-center">Daftar untuk melanjutkan</h5>
		<a class="btn tombol-daftar btn-block" href="<?php echo base_url('daftar'); ?>">Daftar</a>
	</div> <!-- Penutup Col -->
</div> <!-- Penutup Row -->